document.getElementById("container").style.display = "flex";
document.getElementById("container").style.justifyContent = "space-around";
